from setuptools import setup

setup(
    name='Personal assistant project',
    version='0.1.0',
    description='GoIT group project as personal assistant',
    Team_name='Next frontier',
    author_email='moivvas@gmail.com',
    packages=['pers_assist'],
)
